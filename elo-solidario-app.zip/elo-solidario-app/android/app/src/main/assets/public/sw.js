// Service worker: guarda o app no aparelho para abrir offline.
const CACHE = "elo-solidario-v1";
const ASSETS = [
  "./", "./index.html", "./styles.css", "./app.js", "./config.js", "./manifest.webmanifest",
  "./icons/icon-192.png", "./icons/icon-512.png", "./icons/icon-180.png", "./icons/icon-maskable-512.png",
  "./fonts/manrope-latin-600-normal.woff2", "./fonts/manrope-latin-700-normal.woff2",
  "./fonts/dm-sans-latin-400-normal.woff2", "./fonts/dm-sans-latin-500-normal.woff2",
  "./fonts/dm-sans-latin-600-normal.woff2", "./fonts/dm-sans-latin-700-normal.woff2",
  "./fonts/playfair-display-latin-800-italic.woff2",
];

self.addEventListener("install", (e) => {
  e.waitUntil(caches.open(CACHE).then((c) => c.addAll(ASSETS)).then(() => self.skipWaiting()));
});

self.addEventListener("activate", (e) => {
  e.waitUntil(
    caches.keys()
      .then((keys) => Promise.all(keys.filter((k) => k !== CACHE).map((k) => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener("fetch", (e) => {
  const req = e.request;
  if (req.method !== "GET" || new URL(req.url).origin !== location.origin) return; // API passa direto
  e.respondWith(
    caches.match(req, { ignoreSearch: true }).then((hit) => {
      const net = fetch(req).then((res) => {
        if (res.ok) caches.open(CACHE).then((c) => c.put(req, res.clone()));
        return res;
      }).catch(() => hit);
      return hit || net;
    })
  );
});
