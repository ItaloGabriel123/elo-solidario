// Configuração do app.
// API_URL vazio  => MODO DEMONSTRAÇÃO (qualquer e-mail/senha entra; dados fictícios).
// API_URL preenchido => o login faz POST em `${API_URL}/token` (ex.: "https://api.seudominio.org").
// Atenção: em um celular, "localhost" é o próprio aparelho — use o IP da máquina ou um domínio.
window.ELO_CONFIG = {
  API_URL: "",
};
