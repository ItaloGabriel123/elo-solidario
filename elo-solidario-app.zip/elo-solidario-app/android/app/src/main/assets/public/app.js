/* Elo Solidário — Central de Doações (app mobile)
   Front-end em JavaScript puro, sem build. Roda no navegador, como PWA e dentro do Capacitor. */
"use strict";

/* ============ Ícones ============ */
const icons = {
  grid: '<rect x="3" y="3" width="7" height="7" rx="2"/><rect x="14" y="3" width="7" height="7" rx="2"/><rect x="3" y="14" width="7" height="7" rx="2"/><rect x="14" y="14" width="7" height="7" rx="2"/>',
  heart: '<path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.7l-1.1-1.1a5.5 5.5 0 0 0-7.8 7.8l1.1 1.1L12 21l7.7-7.5 1.1-1.1a5.5 5.5 0 0 0 0-7.8Z"/>',
  calendar: '<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M16 3v4M8 3v4M3 10h18"/>',
  box: '<path d="m21 8-9-5-9 5 9 5 9-5Z"/><path d="m3 8 9 5 9-5M3 8v9l9 5 9-5V8M12 13v9"/>',
  clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
  chart: '<path d="M4 20V10M10 20V4M16 20v-7M22 20H2"/>',
  users: '<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.8M16 3.2a4 4 0 0 1 0 7.6"/>',
  user: '<circle cx="12" cy="8" r="4"/><path d="M4 21v-1a6 6 0 0 1 6-6h4a6 6 0 0 1 6 6v1"/>',
  settings: '<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.9l.1.1-2.8 2.8-.1-.1a1.7 1.7 0 0 0-1.9-.3 1.7 1.7 0 0 0-1 1.6v.2h-4V21a1.7 1.7 0 0 0-1-1.6 1.7 1.7 0 0 0-1.9.3l-.1.1L4.2 17l.1-.1a1.7 1.7 0 0 0 .3-1.9A1.7 1.7 0 0 0 3 14H2.8v-4H3a1.7 1.7 0 0 0 1.6-1 1.7 1.7 0 0 0-.3-1.9L4.2 7 7 4.2l.1.1a1.7 1.7 0 0 0 1.9.3A1.7 1.7 0 0 0 10 3V2.8h4V3a1.7 1.7 0 0 0 1 1.6 1.7 1.7 0 0 0 1.9-.3l.1-.1L19.8 7l-.1.1a1.7 1.7 0 0 0-.3 1.9 1.7 1.7 0 0 0 1.6 1h.2v4H21a1.7 1.7 0 0 0-1.6 1Z"/>',
  search: '<circle cx="11" cy="11" r="7"/><path d="m20 20-4-4"/>',
  bell: '<path d="M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9"/><path d="M10 21h4"/>',
  arrow: '<path d="m9 18 6-6-6-6"/>',
  plus: '<path d="M12 5v14M5 12h14"/>',
  minus: '<path d="M5 12h14"/>',
  menu: '<path d="M4 7h16M4 12h16M4 17h16"/>',
  mail: '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3 7 9 6 9-6"/>',
  lock: '<rect x="4" y="11" width="16" height="10" rx="2"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/>',
  logout: '<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4M16 17l5-5-5-5M21 12H9"/>',
  check: '<path d="m5 12 5 5L20 7"/>',
  file: '<path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8Z"/><path d="M14 3v5h5M9 13h6M9 17h6"/>',
  info: '<circle cx="12" cy="12" r="9"/><path d="M12 11v5M12 8h.01"/>',
};
function icon(name, size = 20) {
  return `<svg width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">${icons[name]}</svg>`;
}
const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const norm = (s) => String(s).normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase();

/* ============ Datas ============ */
const pad = (n) => String(n).padStart(2, "0");
const toISO = (d) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
const fromISO = (s) => { const [y, m, d] = s.split("-").map(Number); return new Date(y, m - 1, d); };
const getToday = () => { const n = new Date(); return new Date(n.getFullYear(), n.getMonth(), n.getDate()); };
const isWeekday = (d) => d.getDay() >= 1 && d.getDay() <= 5;
const cap = (s) => s.charAt(0).toUpperCase() + s.slice(1);
const fmtLong = (d) => d.toLocaleDateString("pt-BR", { weekday: "long", day: "numeric", month: "long" });
const monthShort = (d) => d.toLocaleDateString("pt-BR", { month: "short" }).replace(".", "");
const weekdayShort = (d) => d.toLocaleDateString("pt-BR", { weekday: "short" }).replace(".", "").toUpperCase();
function nextWeekday(from) { const d = new Date(from); while (!isWeekday(d)) d.setDate(d.getDate() + 1); return d; }
function nextWeekdays(n) {
  const out = []; const d = getToday();
  while (out.length < n) { if (isWeekday(d)) out.push(new Date(d)); d.setDate(d.getDate() + 1); }
  return out;
}

/* ============ Armazenamento seguro ============ */
const store = {
  get(k) { try { return localStorage.getItem(k); } catch { return null; } },
  set(k, v) { try { localStorage.setItem(k, v); } catch { /* ignora */ } },
  del(k) { try { localStorage.removeItem(k); } catch { /* ignora */ } },
};

/* ============ Dados de demonstração ============ */
const CATEGORIES = ["Alimentos", "Higiene", "Vestuário"];
const PRIORITIES = ["Urgente", "Alta prioridade", "Prioridade média"];
const priorityTone = { "Urgente": "red", "Alta prioridade": "orange", "Prioridade média": "blue" };

let nextId = 100;
let needs = [
  { id: 1, name: "Arroz e feijão", category: "Alimentos", priority: "Alta prioridade", have: 180, goal: 250, unit: "unidades" },
  { id: 2, name: "Leite integral", category: "Alimentos", priority: "Alta prioridade", have: 42, goal: 150, unit: "unidades" },
  { id: 3, name: "Fralda infantil M", category: "Higiene", priority: "Urgente", have: 16, goal: 100, unit: "pacotes" },
  { id: 4, name: "Cobertores", category: "Vestuário", priority: "Prioridade média", have: 34, goal: 60, unit: "unidades" },
];

let stock = [
  { id: 1, item: "Arroz tipo 1", category: "Alimentos", qty: 142 },
  { id: 2, item: "Leite integral", category: "Alimentos", qty: 28 },
  { id: 3, item: "Fralda infantil M", category: "Higiene", qty: 16 },
  { id: 4, item: "Óleo de cozinha", category: "Alimentos", qty: 64 },
  { id: 5, item: "Feijão carioca", category: "Alimentos", qty: 96 },
  { id: 6, item: "Cobertores", category: "Vestuário", qty: 34 },
];
const stockStatus = (qty) => (qty <= 20 ? { label: "Crítico", tone: "red" } : qty <= 40 ? { label: "Baixo", tone: "orange" } : { label: "Estável", tone: "green" });

let movements = [
  { id: 1, item: "Arroz tipo 1", type: "in", qty: 40, who: "Rafael Santos", when: "Hoje, 09:12" },
  { id: 2, item: "Leite integral", type: "out", qty: 12, who: "Marina Costa", when: "Ontem, 16:40" },
  { id: 3, item: "Óleo de cozinha", type: "in", qty: 24, who: "Carla Mendes", when: "Ontem, 10:05" },
];

let appointments = [
  { id: 1, name: "Rafael Santos", time: "09:00", items: "Arroz, feijão e óleo • 6 itens", received: false, color: "blue" },
  { id: 2, name: "Carla Mendes", time: "10:30", items: "Produtos de higiene • 12 itens", received: false, color: "orange" },
  { id: 3, name: "João Lima", time: "13:00", items: "Roupas infantis • 2 volumes", received: false, color: "green" },
  { id: 4, name: "Amanda Brito", time: "14:30", items: "Alimentos não perecíveis • 8 itens", received: false, color: "purple" },
];

const upcomingDefault = toISO(nextWeekday(new Date(getToday().getTime() + 2 * 864e5)));
let bookings = [
  { id: 1, date: upcomingDefault, slot: "10:30", items: "Arroz, feijão e leite • 12 itens", status: "Agendado" },
  { id: 2, date: "2026-07-12", slot: "09:00", items: "Produtos de higiene • 8 itens", status: "Recebido" },
  { id: 3, date: "2026-06-03", slot: "13:00", items: "Roupas infantis • 2 volumes", status: "Recebido" },
];

const SLOTS = [
  { t: "09:00", note: "4 vagas disponíveis" },
  { t: "10:30", note: "2 vagas disponíveis" },
  { t: "13:00", note: "4 vagas disponíveis" },
  { t: "14:30", note: "Capacidade esgotada", full: true },
  { t: "16:00", note: "4 vagas disponíveis" },
];

const CHART = [126, 165, 144, 210, 192, 246, 216]; // itens recebidos, últimos 7 meses
const CHART_MAX = 300;

/* ============ Navegação ============ */
const ROOTS = { doador: ["needs", "schedule", "history", "profile"], admin: ["home", "needs", "agenda", "stock", "more"] };
const PARENT = { moves: "more", reports: "more" };
const TABS = {
  doador: [["needs", "Necessidades", "heart"], ["schedule", "Agendar", "calendar"], ["history", "Contribuições", "box"], ["profile", "Perfil", "user"]],
  admin: [["home", "Início", "grid"], ["needs", "Itens", "heart"], ["agenda", "Agenda", "calendar"], ["stock", "Estoque", "box"], ["more", "Mais", "menu"]],
};
const TITLES = {
  doador: { needs: "Necessidades", schedule: "Agendar entrega", history: "Minhas contribuições", profile: "Perfil" },
  admin: { home: "Visão geral", needs: "Itens necessários", agenda: "Agendamentos", stock: "Estoque", more: "Mais", moves: "Movimentações", reports: "Relatórios" },
};

/* ============ Estado ============ */
const initialDay = nextWeekday(getToday());
const state = {
  authenticated: false,
  loading: false,
  role: "doador",
  page: "needs",
  form: { email: "", password: "", remember: false },
  showPassword: false,
  notice: "",
  noticeError: false,
  sheet: null, // "notif" | "move" | "need" | null
  unread: [0, 1],
  toast: null,
  slot: "10:30",
  selectedDate: toISO(initialDay),
  calMonth: { y: initialDay.getFullYear(), m: initialDay.getMonth() },
  donateItem: null,
  agendaDay: toISO(initialDay),
  stockQuery: "",
  stockCat: "Todas",
  stockStatus: "Todos",
  move: { itemId: 1, type: "in", qty: 10 },
};
let fresh = { page: true, sheet: false, toast: false };
let toastTimer = null;

const firstPage = () => ROOTS[state.role][0];
const tabKey = () => PARENT[state.page] || state.page;

/* ============ Componentes ============ */
function logo() {
  return `<div class="logo"><div class="logo-mark">${icon("heart", 22)}</div><div><b>Elo Solidário</b><span>Central de Doações</span></div></div>`;
}

function loginView() {
  const admin = state.role === "admin";
  const f = state.form;
  return `
  <div class="login theme-${state.role}">
    <section class="login-brand">
      ${logo()}
      <div class="brand-message">
        <p>${admin ? "GESTÃO QUE TRANSFORMA" : "SOLIDARIEDADE QUE APROXIMA"}</p>
        <h1>${admin ? "Organize recursos. Multiplique impactos." : "Toda doação pode transformar uma história."}</h1>
        <span>${admin ? "Uma visão clara para cuidar das doações, do estoque e de cada atendimento." : "Consulte necessidades e agende sua entrega de forma simples e segura."}</span>
      </div>
    </section>
    <main class="card login-box">
      <div class="login-heading"><h2>Bem-vindo de volta</h2><p>Escolha como deseja acessar.</p></div>
      <div class="role-selector" role="group" aria-label="Tipo de acesso">
        <button type="button" class="${!admin ? "selected" : ""}" data-act="role" data-arg="doador" aria-pressed="${!admin}"><span>${icon("heart")}</span><span><b>Sou doador</b><small>Doações e entregas</small></span></button>
        <button type="button" class="${admin ? "selected" : ""}" data-act="role" data-arg="admin" aria-pressed="${admin}"><span>${icon("grid")}</span><span><b>Sou administrador</b><small>Gestão da instituição</small></span></button>
      </div>
      <form id="login-form" autocomplete="on">
        <label for="email">E-mail</label>
        <div class="input-field">${icon("mail", 19)}<input id="email" name="email" required type="email" inputmode="email" autocomplete="username" autocapitalize="off" placeholder="${admin ? "nome@instituicao.org" : "seuemail@exemplo.com"}" value="${esc(f.email)}" /></div>
        <div class="password-label"><label for="password">Senha</label><button type="button" data-act="forgot">Esqueci minha senha</button></div>
        <div class="input-field">${icon("lock", 19)}<input id="password" name="password" required type="${state.showPassword ? "text" : "password"}" autocomplete="current-password" placeholder="Digite sua senha" value="${esc(f.password)}" /><button type="button" data-act="pwd" aria-label="${state.showPassword ? "Ocultar senha" : "Mostrar senha"}">${state.showPassword ? "Ocultar" : "Mostrar"}</button></div>
        <label class="remember"><input type="checkbox" id="remember" ${f.remember ? "checked" : ""} /> Manter-me conectado</label>
        ${state.notice ? `<p class="auth-notice ${state.noticeError ? "error" : ""}" role="status">${esc(state.notice)}</p>` : ""}
        <button class="primary" type="submit" ${state.loading ? "disabled" : ""}>${state.loading ? "Conectando..." : `Entrar como ${admin ? "administrador" : "doador"} ${icon("arrow", 18)}`}</button>
      </form>
      <div class="divider"><span>ou continue com</span></div>
      <div class="social-login"><button type="button" data-act="social"><b>G</b> Google</button><button type="button" data-act="social"><b>m</b> Microsoft</button></div>
      <p class="signup">${admin ? 'Acesso restrito à equipe. <button type="button" data-act="access">Solicitar acesso</button>' : 'Ainda não tem conta? <button type="button" data-act="signup">Cadastre-se grátis</button>'}</p>
    </main>
    <div class="login-foot"><p class="security-note">Ambiente seguro. Dados tratados conforme a LGPD.<br />© 2026 Elo Solidário</p></div>
  </div>`;
}

function notificationItems() {
  const d = fromISO(upcomingDefault);
  const when = `${d.getDate()} de ${d.toLocaleDateString("pt-BR", { month: "long" })}`;
  return state.role === "admin"
    ? [
        { title: "Entrega aguardando confirmação", text: "Rafael Santos chegou para o horário das 09:00.", time: "Agora", icon: "calendar", page: "agenda" },
        { title: "Estoque em nível crítico", text: "Fralda infantil M possui apenas 16 unidades.", time: "Há 18 min", icon: "box", page: "stock" },
        { title: "Nova necessidade publicada", text: "O item Leite integral já está visível aos doadores.", time: "Ontem", icon: "heart", page: "needs" },
      ]
    : [
        { title: "Agendamento confirmado", text: `Sua entrega está marcada para ${when}, às 10:30.`, time: "Agora", icon: "calendar", page: "history" },
        { title: "Nova necessidade urgente", text: "A instituição precisa de fraldas infantis tamanho M.", time: "Há 1 h", icon: "heart", page: "needs" },
        { title: "Obrigado pela sua doação", text: "Sua última entrega de 8 itens foi recebida com sucesso.", time: "12 jul", icon: "box", page: "history" },
      ];
}

function bellButton() {
  return `<button class="icon-btn" data-act="notif-open" aria-label="Notificações${state.unread.length ? `, ${state.unread.length} novas` : ""}">${icon("bell", 21)}${state.unread.length ? "<i></i>" : ""}</button>`;
}

function appView() {
  const admin = state.role === "admin";
  const sub = !!PARENT[state.page];
  const pendingCount = appointments.filter((a) => !a.received).length;
  return `
  <div class="app theme-${state.role}">
    <header class="appbar">
      ${sub ? `<button class="back" data-act="back" aria-label="Voltar">${icon("arrow", 22)}</button>` : `<div class="logo-mark">${icon("heart", 21)}</div>`}
      <div class="titles"><span>${admin ? "Área administrativa" : "Portal do doador"}</span><h1>${TITLES[state.role][state.page]}</h1></div>
      ${bellButton()}
    </header>
    <main class="screen ${fresh.page ? "enter" : ""}" id="screen">${admin ? adminPage() : donorPage()}</main>
    <nav class="tabbar" aria-label="Navegação principal">
      ${TABS[state.role].map(([key, label, ic]) => `<button class="tab ${tabKey() === key ? "active" : ""}" data-act="nav" data-arg="${key}" aria-label="${label}" ${tabKey() === key ? 'aria-current="page"' : ""}>${icon(ic, 23)}<span>${label}</span>${admin && key === "agenda" && pendingCount ? `<i class="badge">${pendingCount}</i>` : ""}</button>`).join("")}
    </nav>
    ${sheetView()}
    ${state.toast ? `<div class="toast ${fresh.toast ? "fresh" : ""}" role="status">${esc(state.toast)}</div>` : ""}
  </div>`;
}

function metric(name, color, label, value, note, warn = false) {
  return `<div class="metric card"><div class="ico ${color}">${icon(name, 19)}</div><span>${label}</span><b>${value}</b><small class="${warn ? "warning" : ""}">${note}</small></div>`;
}
const initials = (name) => name.split(" ").map((p) => p[0]).join("").slice(0, 2);
const progressOf = (n) => Math.min(100, Math.round((n.have / n.goal) * 100));

function stockCard(row, withAction) {
  const st = stockStatus(row.qty);
  return `<div class="card stock-item">
    <div class="stock-top"><div class="ico ${st.tone}">${icon("box", 21)}</div><div class="grow"><b>${esc(row.item)}</b><small>${esc(row.category)}</small></div><div class="stock-qty">${row.qty}<small>un.</small></div></div>
    <div class="stock-foot"><span class="status ${st.tone}">${st.label}</span>${withAction ? `<button class="outline" data-act="move-open" data-arg="${row.id}">Movimentar</button>` : ""}</div>
  </div>`;
}

/* ============ Administrador ============ */
function adminPage() {
  switch (state.page) {
    case "home": return dashboard();
    case "needs": return needsAdmin();
    case "agenda": return agendaPage();
    case "stock": return inventory();
    case "moves": return movesPage();
    case "reports": return reportsPage();
    default: return moreAdmin();
  }
}

function dashboard() {
  const today = getToday();
  const pending = appointments.filter((a) => !a.received).length;
  const attention = stock.filter((s) => stockStatus(s.qty).label !== "Estável");
  const totalQty = stock.reduce((s, r) => s + r.qty, 0);
  const months = Array.from({ length: 7 }, (_, i) => cap(monthShort(new Date(today.getFullYear(), today.getMonth() - (6 - i), 1))));
  const prev = monthShort(new Date(today.getFullYear(), today.getMonth() - 1, 1));
  return `
    <div class="hero"><span class="eyebrow">${esc(fmtLong(today))}</span><h2>Olá, Marina!</h2><p>Aqui está o resumo da Central de Doações hoje.</p></div>
    <div class="section-title"><h2>Resumo</h2></div>
    <section class="metrics">
      ${metric("heart", "blue", "Doações no mês", "186", `+12% vs. ${prev}`)}
      ${metric("calendar", "orange", "Agendamentos hoje", appointments.length, `${pending} aguardando`)}
      ${metric("box", "green", "Itens em estoque", totalQty.toLocaleString("pt-BR"), `${stock.length} tipos de produtos`)}
      ${metric("clock", "purple", "Perto da validade", "8", "Precisam de atenção", true)}
    </section>
    <div class="section-title"><h2>Doações recebidas</h2><p>7 meses</p></div>
    <div class="card card-pad">
      <div class="chart" role="img" aria-label="Gráfico de barras com itens recebidos nos últimos 7 meses">
        <div class="y-axis"><span>300</span><span>200</span><span>100</span><span>0</span></div>
        <div class="bars">${CHART.map((v, i) => `<div class="bar-col ${i === 6 ? "last" : ""}"><div class="bar-wrap"><div class="bar" style="height:${(v / CHART_MAX) * 100}%"></div></div><span>${months[i]}</span></div>`).join("")}</div>
      </div>
    </div>
    <div class="section-title"><h2>Agenda de hoje</h2><button class="ghost" data-act="nav" data-arg="agenda">Ver agenda</button></div>
    <div class="card card-pad">${appointments.map((a) => `<div class="row"><b class="time-chip">${a.time}</b><span class="avatar ${a.color}">${initials(a.name)}</span><div class="grow"><b>${a.name}</b><small>${a.items}</small></div><span class="pill ${a.received ? "" : "gray"}">${a.received ? "Recebido" : "Confirmado"}</span></div>`).join("")}</div>
    <div class="section-title"><h2>Atenção ao estoque</h2><button class="ghost" data-act="nav" data-arg="stock">Ver estoque</button></div>
    <div class="stock-list">${attention.length ? attention.map((r) => stockCard(r, false)).join("") : '<div class="card empty"><b>Tudo em ordem</b><p>Nenhum item com nível baixo.</p></div>'}</div>
    <div class="section-title"><h2>Ações rápidas</h2></div>
    <div class="card card-pad quick-list">
      <button data-act="nav" data-arg="agenda"><span class="ico blue">${icon("calendar")}</span><span class="grow"><b>Confirmar recebimento</b><small>Registrar entrega agendada</small></span>${icon("arrow", 18).replace("<svg", '<svg class="chev"')}</button>
      <button data-act="move-new"><span class="ico green">${icon("box")}</span><span class="grow"><b>Registrar movimentação</b><small>Entrada ou saída de estoque</small></span>${icon("arrow", 18).replace("<svg", '<svg class="chev"')}</button>
      <button data-act="need-open"><span class="ico orange">${icon("heart")}</span><span class="grow"><b>Adicionar necessidade</b><small>Publicar item para doação</small></span>${icon("arrow", 18).replace("<svg", '<svg class="chev"')}</button>
    </div>`;
}

function agendaPage() {
  const days = nextWeekdays(5);
  const isFirst = state.agendaDay === toISO(days[0]);
  const list = isFirst ? appointments : [];
  const pending = list.filter((a) => !a.received).length;
  const sel = fromISO(state.agendaDay);
  return `
    <div class="date-strip" role="tablist" aria-label="Dias">${days.map((d) => `<button role="tab" class="${toISO(d) === state.agendaDay ? "selected" : ""}" aria-selected="${toISO(d) === state.agendaDay}" data-act="agenda-day" data-arg="${toISO(d)}"><span>${d.getDate()}</span><span>${weekdayShort(d)}</span></button>`).join("")}</div>
    <div class="card card-pad">
      <div class="card-head"><div><h2>${esc(cap(fmtLong(sel)))}</h2><p>${list.length} agendamentos • ${pending} aguardando confirmação</p></div></div>
      ${list.length ? list.map((a, i) => `
        <div class="schedule-row">
          <div class="time"><b class="time">${a.time}</b><small>até ${i % 2 ? "11:00" : `${Number(a.time.slice(0, 2)) + 1}:00`}</small></div>
          <div class="who"><span class="avatar ${a.color}">${initials(a.name)}</span><div class="info"><b>${a.name}</b><small>${a.items}</small></div></div>
          <div class="act">${a.received ? '<span class="status green">Recebido</span>' : `<button class="outline" style="width:100%" data-act="confirm" data-arg="${a.id}">${icon("check", 18)} Confirmar recebimento</button>`}</div>
        </div>`).join("") : '<div class="empty"><div class="ico blue">' + icon("calendar") + "</div><b>Nenhum agendamento</b><p>Não há entregas previstas para este dia.</p></div>"}
    </div>`;
}

function filteredStock() {
  const q = norm(state.stockQuery.trim());
  return stock.filter((r) =>
    (!q || norm(r.item).includes(q)) &&
    (state.stockCat === "Todas" || r.category === state.stockCat) &&
    (state.stockStatus === "Todos" || stockStatus(r.qty).label === state.stockStatus));
}
function stockResults() {
  const rows = filteredStock();
  return rows.length ? rows.map((r) => stockCard(r, true)).join("") : `<div class="card empty"><div class="ico blue">${icon("search")}</div><b>Nada encontrado</b><p>Tente outro termo ou limpe os filtros.</p></div>`;
}
function inventory() {
  const chip = (act, val, cur) => `<button class="chip ${cur === val ? "selected" : ""}" data-act="${act}" data-arg="${val}" aria-pressed="${cur === val}">${val}</button>`;
  return `
    <button class="primary" data-act="move-new" style="margin-bottom:14px">${icon("plus", 19)} Nova movimentação</button>
    <label class="search">${icon("search", 19)}<input id="stock-q" type="search" placeholder="Buscar produto..." value="${esc(state.stockQuery)}" aria-label="Buscar produto" autocomplete="off" /></label>
    <div class="chips" aria-label="Categorias">${["Todas", ...CATEGORIES].map((c) => chip("stock-cat", c, state.stockCat)).join("")}</div>
    <div class="chips" aria-label="Status">${["Todos", "Crítico", "Baixo", "Estável"].map((c) => chip("stock-status", c, state.stockStatus)).join("")}</div>
    <div class="stock-list" id="stock-results">${stockResults()}</div>`;
}

function needsAdmin() {
  return `
    <button class="primary" data-act="need-open" style="margin-bottom:14px">${icon("plus", 19)} Adicionar item</button>
    <div class="stock-list">${needs.map((n) => `
      <div class="card need">
        <div class="need-top"><div class="ico ${priorityTone[n.priority]}">${icon("heart")}</div><div class="grow"><h3>${esc(n.name)}</h3><p>${esc(n.category)}</p></div><span class="status ${priorityTone[n.priority]}">${n.priority}</span></div>
        <div><div class="need-meta"><span>${n.have} de ${n.goal} ${n.unit === "pacotes" ? "pct." : "un."}</span><b>${progressOf(n)}%</b></div><div class="progress"><i style="width:${progressOf(n)}%"></i></div></div>
      </div>`).join("")}</div>`;
}

function movesPage() {
  return `<div class="card card-pad">${movements.map((m) => `
    <div class="move-item"><div class="ico ${m.type === "in" ? "green" : "red"}">${icon(m.type === "in" ? "plus" : "minus", 20)}</div><div class="grow"><b>${esc(m.item)}</b><small>${m.type === "in" ? "Entrada" : "Saída"} • ${esc(m.who)} • ${esc(m.when)}</small></div><span class="move-qty ${m.type}">${m.type === "in" ? "+" : "−"}${m.qty}</span></div>`).join("")}</div>
    <button class="primary" data-act="move-new" style="margin-top:14px">${icon("plus", 19)} Nova movimentação</button>`;
}

function reportsPage() {
  const rows = [["Doações por período", "Itens recebidos por mês", "blue", "calendar"], ["Estoque por categoria", "Saldo atual de cada categoria", "green", "box"], ["Validades próximas", "Produtos que vencem em 30 dias", "orange", "clock"]];
  return `
    <div class="metrics three">
      ${metric("heart", "blue", "Doações no semestre", "1.047", "+9% vs. semestre anterior")}
      ${metric("box", "green", "Itens distribuídos", "912", "87% do recebido")}
      ${metric("users", "purple", "Famílias atendidas", "138", "Neste semestre")}
    </div>
    <div class="section-title"><h2>Gerar relatório</h2></div>
    <div class="card menu-list">${rows.map(([t, s, c, i]) => `<button data-act="toast" data-arg="Relatório “${t}” será gerado quando o servidor estiver conectado."><span class="ico ${c}">${icon(i, 19)}</span><span class="grow">${t}<small style="display:block;font-weight:400;font-size:13px;color:var(--muted)">${s}</small></span>${icon("arrow", 18).replace("<svg", '<svg class="chev"')}</button>`).join("")}</div>`;
}

function profileCard(name, role, email) {
  return `<div class="card profile"><span class="avatar">${initials(name)}</span><div><b>${name}</b><small>${role}</small><small>${esc(email)}</small></div></div>
    <div class="impact"><span>Impacto este mês</span><b>1.284</b><small>itens recebidos</small><div class="progress"><i style="width:72%"></i></div><em>72% da meta mensal</em></div>`;
}
function menuRow(ic, color, label, act, arg = "", extra = "") {
  return `<button data-act="${act}" ${arg ? `data-arg="${esc(arg)}"` : ""}><span class="ico ${color} ${extra}">${icon(ic, 19)}</span><span class="grow ${extra}">${label}</span>${extra ? "" : icon("arrow", 18).replace("<svg", '<svg class="chev"')}</button>`;
}
function moreAdmin() {
  const email = state.form.email || "marina@instituicao.org";
  return `${profileCard("Marina Costa", "Administradora", email)}
    <div class="card menu-list">
      ${menuRow("clock", "blue", "Movimentações", "nav", "moves")}
      ${menuRow("chart", "green", "Relatórios", "nav", "reports")}
      ${menuRow("users", "purple", "Equipe e acessos", "toast", "Gestão de equipe em breve nesta versão.")}
      ${menuRow("settings", "orange", "Configurações", "toast", "Configurações em breve nesta versão.")}
    </div>
    <div class="card menu-list" style="margin-top:14px">${menuRow("logout", "red", "Sair da conta", "logout", "", "danger")}</div>
    <p class="version">Elo Solidário • versão 1.0.0</p>`;
}

/* ============ Doador ============ */
function donorPage() {
  switch (state.page) {
    case "schedule": return donorSchedule();
    case "history": return contributions();
    case "profile": return profileDonor();
    default: return donorNeeds();
  }
}

function donorNeeds() {
  const sorted = [...needs].sort((a, b) => PRIORITIES.indexOf(a.priority) - PRIORITIES.indexOf(b.priority));
  return `
    <div class="hero"><span class="eyebrow">Faça parte dessa rede</span><h2>Sua doação transforma histórias.</h2><p>Confira o que precisamos neste momento e ajude a levar cuidado a quem mais precisa.</p>
      <div class="hero-stat">${icon("heart", 30)}<div><b>1.284</b><small>itens doados este mês</small></div></div>
      <button class="primary" data-act="nav" data-arg="schedule">Agendar uma entrega ${icon("arrow", 18)}</button></div>
    <div class="section-title"><div><h2>Necessidades prioritárias</h2><p>O que mais faz diferença agora</p></div></div>
    <div class="stock-list">${sorted.map((n) => `
      <div class="card need">
        <div class="need-top"><div class="ico ${priorityTone[n.priority]}">${icon("heart")}</div><div class="grow"><h3>${esc(n.name)}</h3><p>${esc(n.category)}</p></div><span class="status ${priorityTone[n.priority]}">${n.priority}</span></div>
        <div><div class="need-meta"><span>Precisamos de ${Math.max(0, n.goal - n.have)} ${n.unit}</span><b>${progressOf(n)}%</b></div><div class="progress"><i style="width:${progressOf(n)}%"></i></div></div>
        <button class="outline" data-act="donate" data-arg="${n.id}">Quero doar ${icon("arrow", 17)}</button>
      </div>`).join("")}</div>`;
}

function donorSchedule() {
  const { y, m } = state.calMonth;
  const today = getToday();
  const first = new Date(y, m, 1);
  const total = new Date(y, m + 1, 0).getDate();
  const isCurrent = y === today.getFullYear() && m === today.getMonth();
  const cells = [...Array(first.getDay()).fill('<i aria-hidden="true"></i>')];
  for (let day = 1; day <= total; day++) {
    const d = new Date(y, m, day); const iso = toISO(d);
    const dis = d < today || !isWeekday(d);
    cells.push(`<button class="${iso === state.selectedDate ? "selected" : ""} ${iso === toISO(today) ? "today" : ""}" ${dis ? "disabled" : ""} data-act="day" data-arg="${iso}" aria-label="${d.toLocaleDateString("pt-BR", { weekday: "long", day: "numeric", month: "long" })}" ${iso === state.selectedDate ? 'aria-pressed="true"' : ""}>${day}</button>`);
  }
  const sel = fromISO(state.selectedDate);
  const need = state.donateItem && needs.find((n) => n.id === state.donateItem);
  return `
    ${need ? `<div class="donate-chip">${icon("heart", 18)}<span>Doando: <b>${esc(need.name)}</b></span><button data-act="clear-donate">Remover</button></div>` : ""}
    <div class="card card-pad">
      <div class="calendar-head"><button data-act="cal-prev" ${isCurrent ? "disabled" : ""} aria-label="Mês anterior"><span aria-hidden="true">‹</span></button><b>${cap(new Date(y, m, 1).toLocaleDateString("pt-BR", { month: "long", year: "numeric" }))}</b><button data-act="cal-next" aria-label="Próximo mês"><span aria-hidden="true">›</span></button></div>
      <div class="week">${["DOM", "SEG", "TER", "QUA", "QUI", "SEX", "SÁB"].map((d) => `<b>${d}</b>`).join("")}${cells.join("")}</div>
    </div>
    <div class="section-title"><div><h2>Horários disponíveis</h2><p>${esc(cap(fmtLong(sel)))}</p></div></div>
    <div style="margin-top:-6px">${SLOTS.map((s) => `<button class="slot ${state.slot === s.t ? "selected" : ""}" ${s.full ? "disabled" : ""} data-act="slot" data-arg="${s.t}" aria-pressed="${state.slot === s.t}">${icon("clock", 20)}<span class="grow"><b>${s.t}</b><small>${s.note}</small></span>${s.full ? '<span class="status gray">Esgotado</span>' : ""}</button>`).join("")}</div>
    <p class="booking-summary">Entrega em <b>${esc(cap(fmtLong(sel)))}</b> às <b>${state.slot}</b></p>
    <button class="primary" data-act="book" style="margin-top:14px">Confirmar agendamento às ${state.slot}</button>`;
}

function contributions() {
  const sorted = [...bookings].sort((a, b) => b.date.localeCompare(a.date));
  const todayISO = toISO(getToday());
  const next = bookings.filter((b) => b.status === "Agendado" && b.date >= todayISO).sort((a, b) => a.date.localeCompare(b.date))[0];
  const nd = next && fromISO(next.date);
  return `
    <div class="metrics three">
      ${metric("heart", "blue", "Doações realizadas", 7, "Obrigado por fazer a diferença")}
      ${metric("box", "green", "Itens doados", "46", "Em 4 categorias")}
      ${metric("calendar", "orange", "Próxima entrega", next ? `${nd.getDate()} ${monthShort(nd)}` : "—", next ? `às ${next.slot}` : "Nenhuma agendada")}
    </div>
    <div class="section-title"><div><h2>Histórico</h2><p>Seus agendamentos e entregas recentes</p></div></div>
    <div class="card card-pad">${sorted.map((b) => { const d = fromISO(b.date); return `
      <div class="contribution"><div class="date-box"><b>${d.getDate()}</b><span>${monthShort(d)}</span></div><div class="grow"><b>${esc(b.items)}</b><small>Central Elo Solidário • ${b.slot}</small></div><span class="status ${b.status === "Recebido" ? "green" : "blue"}">${b.status}</span></div>`; }).join("")}</div>`;
}

function profileDonor() {
  const email = state.form.email || "ana.souza@exemplo.com";
  return `${profileCard("Ana Souza", "Doadora", email)}
    <div class="card menu-list">
      ${menuRow("bell", "blue", "Notificações", "notif-open")}
      ${menuRow("calendar", "green", "Minhas contribuições", "nav", "history")}
      ${menuRow("info", "purple", "Sobre o Elo Solidário", "toast", "Elo Solidário • versão 1.0.0")}
    </div>
    <div class="card menu-list" style="margin-top:14px">${menuRow("logout", "red", "Sair da conta", "logout", "", "danger")}</div>
    <p class="version">Elo Solidário • versão 1.0.0</p>`;
}

/* ============ Sheets ============ */
function sheetView() {
  if (!state.sheet) return "";
  const f = fresh.sheet ? "fresh" : "";
  let head = "", body = "";
  if (state.sheet === "notif") {
    const items = notificationItems();
    head = `<div><h3>Notificações</h3><span>${state.unread.length ? `${state.unread.length} novas` : "Tudo em dia"}</span></div><button data-act="sheet-close">Fechar</button>`;
    body = `<div class="sheet-body">${state.unread.length ? '<button class="ghost" data-act="read-all">Marcar todas como lidas</button>' : ""}${items.map((it, i) => `
      <button class="notification-item ${state.unread.includes(i) ? "unread" : ""}" data-act="notif-item" data-arg="${i}" data-page="${it.page}">
        <span class="notification-icon">${icon(it.icon, 20)}</span>
        <span class="notification-copy"><b>${it.title}</b><span>${it.text}</span><small>${it.time}</small></span>${state.unread.includes(i) ? "<em></em>" : ""}
      </button>`).join("")}
      <button class="ghost" data-act="all-activities" style="width:100%;justify-content:center;margin-top:6px">Ver todas as atividades ${icon("arrow", 16)}</button></div>`;
  } else if (state.sheet === "move") {
    const m = state.move;
    head = `<div><h3>Nova movimentação</h3><span>Registre entrada ou saída de estoque</span></div><button data-act="sheet-close">Fechar</button>`;
    body = `<div class="sheet-body form">
      <label for="move-item" style="display:block;font-size:13px;font-weight:600;color:#455951;margin:0 0 6px">Produto</label>
      <select class="select" id="move-item" aria-label="Produto">${stock.map((s) => `<option value="${s.id}" ${s.id === m.itemId ? "selected" : ""}>${esc(s.item)}</option>`).join("")}</select>
      <div class="seg" style="margin:16px 0" role="group" aria-label="Tipo"><button type="button" data-act="move-type" data-arg="in" class="${m.type === "in" ? "selected" : ""}">${icon("plus", 17)} Entrada</button><button type="button" data-act="move-type" data-arg="out" class="${m.type === "out" ? "selected" : ""}">${icon("minus", 17)} Saída</button></div>
      <div class="stepper"><button type="button" data-act="move-step" data-arg="-5" aria-label="Diminuir">−</button><input id="move-qty" type="number" inputmode="numeric" min="1" value="${m.qty}" aria-label="Quantidade" /><button type="button" data-act="move-step" data-arg="5" aria-label="Aumentar">+</button></div>
      <p class="field-note" id="move-preview"></p>
      <p class="auth-notice error" id="move-error" role="alert" hidden></p>
      <div class="form-actions"><button class="primary" data-act="move-save">Registrar ${m.type === "in" ? "entrada" : "saída"}</button></div></div>`;
  } else if (state.sheet === "need") {
    head = `<div><h3>Adicionar necessidade</h3><span>Publique um item para os doadores</span></div><button data-act="sheet-close">Fechar</button>`;
    body = `<div class="sheet-body form">
      <label for="need-name" style="display:block;font-size:13px;font-weight:600;color:#455951;margin:0 0 6px">Nome do item</label>
      <div class="input-field"><input id="need-name" type="text" maxlength="40" placeholder="Ex.: Macarrão" autocomplete="off" /></div>
      <label for="need-cat">Categoria</label><select class="select" id="need-cat">${CATEGORIES.map((c) => `<option>${c}</option>`).join("")}</select>
      <label for="need-pri">Prioridade</label><select class="select" id="need-pri">${PRIORITIES.map((c) => `<option ${c === "Prioridade média" ? "selected" : ""}>${c}</option>`).join("")}</select>
      <label for="need-goal">Quantidade necessária</label><div class="input-field"><input id="need-goal" type="number" inputmode="numeric" min="1" placeholder="Ex.: 100" /></div>
      <p class="auth-notice error" id="need-error" role="alert" hidden></p>
      <div class="form-actions"><button class="primary" data-act="need-save">Publicar necessidade</button></div></div>`;
  }
  return `<div class="overlay ${f}" data-act="sheet-close"></div>
    <section class="sheet ${f}" role="dialog" aria-modal="true" aria-label="${state.sheet === "notif" ? "Notificações" : state.sheet === "move" ? "Nova movimentação" : "Adicionar necessidade"}">
      <div class="sheet-handle"></div><div class="sheet-head">${head}</div>${body}
    </section>`;
}

/* ============ Render ============ */
function render() {
  const root = document.getElementById("app");
  const prev = document.getElementById("screen");
  const top = prev && !fresh.page ? prev.scrollTop : 0;
  root.innerHTML = state.authenticated ? appView() : loginView();
  const screen = document.getElementById("screen");
  if (screen && top) screen.scrollTop = top;
  fresh = { page: false, sheet: false, toast: false };
  if (state.sheet === "move") updateMoveUI();
}

function go(page) {
  state.page = page; state.sheet = null; fresh.page = true; render();
  const s = document.getElementById("screen"); if (s) s.scrollTop = 0;
}
function openSheet(name) { state.sheet = name; fresh.sheet = true; render(); }
function closeSheet() { state.sheet = null; render(); }
function showToast(msg) {
  state.toast = msg; fresh.toast = true; render();
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => { state.toast = null; const el = document.querySelector(".toast"); if (el) el.remove(); }, 2800);
}

/* ============ Movimentação (atualização sem re-render) ============ */
function updateMoveUI() {
  const m = state.move;
  const item = stock.find((s) => s.id === m.itemId);
  const qty = Math.max(0, Math.floor(Number(m.qty) || 0));
  const after = item ? item.qty + (m.type === "in" ? qty : -qty) : 0;
  const prev = document.getElementById("move-preview");
  if (prev && item) prev.textContent = `Saldo atual: ${item.qty} un. → após registrar: ${after < 0 ? "—" : after + " un."}`;
  const input = document.getElementById("move-qty");
  if (input && document.activeElement !== input) input.value = m.qty;
  document.querySelectorAll('[data-act="move-type"]').forEach((b) => b.classList.toggle("selected", b.dataset.arg === m.type));
  const save = document.querySelector('[data-act="move-save"]');
  if (save) save.textContent = `Registrar ${m.type === "in" ? "entrada" : "saída"}`;
}
function showSheetError(id, msg) { const el = document.getElementById(id); if (el) { el.textContent = msg; el.hidden = !msg; } }

function saveMovement() {
  const m = state.move;
  const item = stock.find((s) => s.id === m.itemId);
  const qty = Math.floor(Number(m.qty));
  if (!item) return;
  if (!qty || qty < 1) return showSheetError("move-error", "Informe uma quantidade maior que zero.");
  if (m.type === "out" && qty > item.qty) return showSheetError("move-error", `Saldo insuficiente: há apenas ${item.qty} un. em estoque.`);
  item.qty += m.type === "in" ? qty : -qty;
  movements.unshift({ id: nextId++, item: item.item, type: m.type, qty, who: "Marina Costa", when: "Agora" });
  state.sheet = null;
  showToast(`${m.type === "in" ? "Entrada" : "Saída"} de ${qty} un. de ${item.item} registrada.`);
}

function saveNeed() {
  const name = document.getElementById("need-name").value.trim();
  const goal = Math.floor(Number(document.getElementById("need-goal").value));
  if (!name) return showSheetError("need-error", "Informe o nome do item.");
  if (!goal || goal < 1) return showSheetError("need-error", "Informe uma quantidade maior que zero.");
  needs.unshift({ id: nextId++, name, category: document.getElementById("need-cat").value, priority: document.getElementById("need-pri").value, have: 0, goal, unit: "unidades" });
  state.sheet = null;
  showToast(`“${name}” publicado para os doadores.`);
}

/* ============ Autenticação ============ */
const API_URL = ((window.ELO_CONFIG && window.ELO_CONFIG.API_URL) || "").replace(/\/$/, "");

async function doLogin(form) {
  const email = form.email.value.trim(), password = form.password.value;
  state.form = { email, password, remember: form.remember ? form.remember.checked : state.form.remember };
  state.loading = true; state.notice = ""; render();
  try {
    let token = "demo";
    if (API_URL) {
      const body = new FormData();
      body.append("username", email); body.append("email", email); body.append("password", password);
      const ctrl = new AbortController(); const t = setTimeout(() => ctrl.abort(), 12000);
      const res = await fetch(`${API_URL}/token`, { method: "POST", body, signal: ctrl.signal }).finally(() => clearTimeout(t));
      if (!res.ok) throw Object.assign(new Error("auth"), { auth: true });
      token = (await res.json()).access_token || "";
    } else {
      await new Promise((r) => setTimeout(r, 500)); // simula rede no modo demonstração
    }
    if (state.form.remember) store.set("elo.session", JSON.stringify({ role: state.role, token }));
    enterApp(); return;
  } catch (err) {
    state.noticeError = true;
    state.notice = err && err.auth ? "Credenciais inválidas." : "Erro ao conectar com o servidor. Verifique sua internet.";
  }
  state.loading = false; render();
}
function enterApp() {
  state.authenticated = true; state.loading = false; state.notice = ""; state.sheet = null;
  state.page = firstPage(); fresh.page = true; render();
}
function logout() {
  store.del("elo.session"); store.del("token");
  state.authenticated = false; state.sheet = null; state.notice = ""; state.form.password = ""; render();
}

/* ============ Eventos ============ */
document.addEventListener("submit", (e) => {
  if (e.target.id === "login-form") { e.preventDefault(); if (!state.loading) doLogin(e.target); }
});

document.addEventListener("input", (e) => {
  const t = e.target;
  if (t.id === "email") state.form.email = t.value;
  else if (t.id === "password") state.form.password = t.value;
  else if (t.id === "stock-q") { state.stockQuery = t.value; const box = document.getElementById("stock-results"); if (box) box.innerHTML = stockResults(); }
  else if (t.id === "move-qty") { state.move.qty = t.value; updateMoveUI(); }
});
document.addEventListener("change", (e) => {
  const t = e.target;
  if (t.id === "remember") state.form.remember = t.checked;
  else if (t.id === "move-item") { state.move.itemId = Number(t.value); updateMoveUI(); }
});

document.addEventListener("click", (e) => {
  const el = e.target.closest("[data-act]");
  if (!el || el.disabled) return;
  const act = el.dataset.act, arg = el.dataset.arg;
  switch (act) {
    case "role": state.role = arg; state.notice = ""; return render();
    case "pwd": state.showPassword = !state.showPassword; return render();
    case "forgot": state.noticeError = false; state.notice = "Enviamos as instruções de recuperação para o seu e-mail."; return render();
    case "signup": state.noticeError = false; state.notice = "Cadastro iniciado. Enviaremos a confirmação por e-mail."; return render();
    case "access": state.noticeError = false; state.notice = "Solicitação enviada ao responsável."; return render();
    case "social":
      if (API_URL) { state.noticeError = true; state.notice = "Login social indisponível no momento."; return render(); }
      return enterApp();
    case "logout": return logout();
    case "nav": return go(arg);
    case "back": return goBack();
    case "notif-open": return openSheet("notif");
    case "sheet-close": return closeSheet();
    case "notif-item": {
      const i = Number(arg); state.unread = state.unread.filter((n) => n !== i);
      return go(el.dataset.page);
    }
    case "read-all": state.unread = []; return render();
    case "all-activities": return go(state.role === "admin" ? "agenda" : "history");
    case "confirm": {
      const a = appointments.find((x) => x.id === Number(arg));
      if (a) { a.received = true; render(); showToast(`Recebimento de ${a.name} confirmado.`); }
      return;
    }
    case "agenda-day": state.agendaDay = arg; return render();
    case "stock-cat": state.stockCat = arg; return render();
    case "stock-status": state.stockStatus = arg; return render();
    case "move-open": state.move = { itemId: Number(arg), type: "in", qty: 10 }; return openSheet("move");
    case "move-new": state.move = { itemId: stock[0].id, type: "in", qty: 10 }; return openSheet("move");
    case "move-type": state.move.type = arg; showSheetError("move-error", ""); return updateMoveUI();
    case "move-step": state.move.qty = Math.max(1, (Math.floor(Number(state.move.qty)) || 0) + Number(arg)); return updateMoveUI();
    case "move-save": return saveMovement();
    case "need-open": return openSheet("need");
    case "need-save": return saveNeed();
    case "donate": state.donateItem = Number(arg); return go("schedule");
    case "clear-donate": state.donateItem = null; return render();
    case "day": state.selectedDate = arg; return render();
    case "cal-prev": { const { y, m } = state.calMonth; state.calMonth = m === 0 ? { y: y - 1, m: 11 } : { y, m: m - 1 }; return render(); }
    case "cal-next": { const { y, m } = state.calMonth; state.calMonth = m === 11 ? { y: y + 1, m: 0 } : { y, m: m + 1 }; return render(); }
    case "slot": state.slot = arg; return render();
    case "book": {
      const need = state.donateItem && needs.find((n) => n.id === state.donateItem);
      bookings.push({ id: nextId++, date: state.selectedDate, slot: state.slot, items: need ? `${need.name} • doação` : "Doação geral", status: "Agendado" });
      const d = fromISO(state.selectedDate);
      state.donateItem = null; go("history");
      return showToast(`Entrega agendada para ${d.getDate()} de ${d.toLocaleDateString("pt-BR", { month: "long" })}, às ${state.slot}.`);
    }
    case "toast": return showToast(arg);
  }
});

/* ============ Botão voltar (Android) e Capacitor ============ */
function goBack() {
  if (state.sheet) return closeSheet();
  if (!state.authenticated) return false;
  if (PARENT[state.page]) return go(PARENT[state.page]);
  if (state.page !== firstPage()) return go(firstPage());
  return false; // já na tela inicial
}
const Cap = window.Capacitor;
const isNative = !!(Cap && Cap.isNativePlatform && Cap.isNativePlatform());
if (isNative && Cap.Plugins && Cap.Plugins.App) {
  Cap.Plugins.App.addListener("backButton", () => { if (goBack() === false) Cap.Plugins.App.exitApp(); });
}
document.addEventListener("keydown", (e) => { if (e.key === "Escape" && state.sheet) closeSheet(); });

/* ============ Inicialização ============ */
(function init() {
  try {
    const saved = JSON.parse(store.get("elo.session") || "null");
    if (saved && ROOTS[saved.role]) { state.role = saved.role; state.form.remember = true; state.authenticated = true; state.page = firstPage(); }
  } catch { store.del("elo.session"); }
  render();
  if ("serviceWorker" in navigator && !isNative && /^https?:$/.test(location.protocol)) {
    navigator.serviceWorker.register("sw.js").catch(() => {});
  }
})();
