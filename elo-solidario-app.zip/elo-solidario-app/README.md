# Elo Solidário — App mobile (front-end)

App de celular para a Central de Doações, com duas áreas: **Doador** e **Administrador**.
JavaScript puro (sem build), pronto para rodar como **PWA** e para empacotar como **app nativo** com Capacitor.

## Rodar no navegador
```bash
npm install
npm start          # http://localhost:5173  (abra no celular pela rede ou use o modo celular do DevTools)
```
No Chrome do celular: menu ⋮ → **Instalar app** (PWA, funciona offline).

## Modo demonstração x servidor
`www/config.js` → `API_URL`:
- vazio (padrão): qualquer e-mail/senha entra; dados fictícios.
- preenchido (ex.: `https://api.seudominio.org`): o login faz `POST {API_URL}/token` (campos `username`, `email`, `password`).
  Em celular, **não use `localhost`** — use IP da rede ou domínio com HTTPS.

## Gerar o app Android / iOS
```bash
npm install
npx cap sync                # copia www/ para os projetos nativos
npx cap open android        # abre no Android Studio -> Run / Build > Generate APK
npx cap open ios            # abre no Xcode (precisa de macOS)
```
Pastas `android/` e `ios/` já estão geradas. O botão voltar do Android já é tratado.
Para trocar o ícone/splash nativos: `npm i -D @capacitor/assets` e `npx capacitor-assets generate` (use `www/icons/icon-512.png` como base).

## Testes
```bash
npm i -D playwright && npx playwright install chromium   # uma vez
npm test                                                  # 18 testes E2E em viewports de celular
```

## Estrutura
- `www/` — app (index.html, app.js, styles.css, sw.js, manifest, fontes e ícones)
- `tests/` — servidor estático + testes
- `android/`, `ios/` — projetos nativos Capacitor
