// Testes de ponta a ponta (Playwright + node:test) em viewports de celular.
// Rodar: npm test
const { test, before, after } = require("node:test");
const assert = require("node:assert/strict");
const { chromium, devices } = require("playwright");
const { createServer } = require("./serve.js");

let srv, browser, URL;
before(async () => {
  srv = createServer().listen(0);
  URL = `http://localhost:${srv.address().port}/`;
  browser = await chromium.launch();
});
after(async () => { await browser.close(); srv.close(); });

async function open(device = "Pixel 7") {
  const ctx = await browser.newContext({ ...devices[device] });
  const page = await ctx.newPage();
  page.errors = [];
  page.on("pageerror", (e) => page.errors.push(e.message));
  page.on("console", (m) => m.type() === "error" && page.errors.push(m.text()));
  await page.goto(URL);
  return { ctx, page };
}
async function login(page, role = "doador", remember = false) {
  await page.click(`.role-selector [data-arg="${role}"]`);
  await page.fill("#email", "teste@exemplo.com");
  await page.fill("#password", "senha123");
  if (remember) await page.check("#remember");
  await page.click(".login .primary");
  await page.waitForSelector(".tabbar");
}
const title = (page) => page.textContent(".appbar h1");
const noHScroll = (page) => page.evaluate(() => {
  const s = document.getElementById("screen") || document.querySelector(".login");
  return document.documentElement.scrollWidth <= window.innerWidth && s.scrollWidth <= s.clientWidth;
});

test("login: renderiza, alterna perfil e mostra/oculta senha sem perder o e-mail", async () => {
  const { ctx, page } = await open();
  assert.match(await page.textContent(".brand-message h1"), /Toda doação/);
  await page.fill("#email", "ana@exemplo.com");
  await page.click('[data-act="pwd"]');
  assert.equal(await page.inputValue("#email"), "ana@exemplo.com", "e-mail preservado ao re-renderizar");
  assert.equal(await page.getAttribute("#password", "type"), "text");
  await page.click('[data-arg="admin"]');
  assert.match(await page.textContent(".brand-message h1"), /Organize recursos/);
  assert.equal(await page.inputValue("#email"), "ana@exemplo.com");
  assert.equal(page.errors.length, 0, page.errors.join("\n"));
  await ctx.close();
});

test("login: validação nativa impede envio vazio", async () => {
  const { ctx, page } = await open();
  await page.click(".login .primary");
  assert.equal(await page.locator(".tabbar").count(), 0);
  assert.equal(await page.evaluate(() => document.getElementById("email").validity.valueMissing), true);
  await ctx.close();
});

test("login: links auxiliares exibem avisos", async () => {
  const { ctx, page } = await open();
  await page.click('[data-act="forgot"]');
  assert.match(await page.textContent(".auth-notice"), /recuperação/);
  await page.click('[data-act="signup"]');
  assert.match(await page.textContent(".auth-notice"), /Cadastro iniciado/);
  await ctx.close();
});

test("doador: navega pelas 4 abas e título muda", async () => {
  const { ctx, page } = await open();
  await login(page);
  assert.equal(await title(page), "Necessidades");
  for (const [arg, t] of [["schedule", "Agendar entrega"], ["history", "Minhas contribuições"], ["profile", "Perfil"], ["needs", "Necessidades"]]) {
    await page.click(`.tab[data-arg="${arg}"]`);
    assert.equal(await title(page), t);
    assert.equal(await page.getAttribute(`.tab[data-arg="${arg}"]`, "aria-current"), "page");
    assert.equal(await noHScroll(page), true, `sem rolagem horizontal em ${t}`);
  }
  assert.equal(page.errors.length, 0, page.errors.join("\n"));
  await ctx.close();
});

test("doador: 'Quero doar' leva ao agendamento e o fluxo completo cria a contribuição", async () => {
  const { ctx, page } = await open();
  await login(page);
  await page.locator('[data-act="donate"]').first().click();
  assert.equal(await title(page), "Agendar entrega");
  assert.match(await page.textContent(".donate-chip"), /Doando:/);
  await page.click('.slot[data-arg="13:00"]');
  assert.equal(await page.getAttribute('.slot[data-arg="13:00"]', "aria-pressed"), "true");
  assert.equal(await page.isDisabled('.slot[data-arg="14:30"]'), true, "horário esgotado desabilitado");
  assert.match(await page.textContent('[data-act="book"]'), /13:00/);
  await page.click('[data-act="book"]');
  assert.equal(await title(page), "Minhas contribuições");
  assert.match(await page.textContent(".toast"), /Entrega agendada/);
  assert.match(await page.textContent(".screen"), /doação/);
  assert.equal(await page.locator(".contribution").count(), 4);
  await ctx.close();
});

test("doador: calendário não permite fins de semana nem dias passados e troca de mês", async () => {
  const { ctx, page } = await open();
  await login(page);
  await page.click('.tab[data-arg="schedule"]');
  assert.equal(await page.isDisabled('[data-act="cal-prev"]'), true);
  const bad = await page.evaluate(() => [...document.querySelectorAll(".week button[data-arg]")].filter((b) => {
    const [y, m, d] = b.dataset.arg.split("-").map(Number); const dt = new Date(y, m - 1, d);
    const t = new Date(); t.setHours(0, 0, 0, 0);
    return !b.disabled && (dt < t || [0, 6].includes(dt.getDay()));
  }).length);
  assert.equal(bad, 0);
  const before = await page.textContent(".calendar-head b");
  await page.click('[data-act="cal-next"]');
  assert.notEqual(await page.textContent(".calendar-head b"), before);
  assert.equal(await page.isDisabled('[data-act="cal-prev"]'), false);
  await page.locator(".week button:not([disabled])").first().click();
  assert.equal(await page.locator(".week button.selected").count(), 1);
  await ctx.close();
});

test("notificações: abrir, marcar como lida, navegar, fechar", async () => {
  const { ctx, page } = await open();
  await login(page);
  assert.equal(await page.locator(".appbar .icon-btn i").count(), 1);
  await page.click('[data-act="notif-open"]');
  assert.match(await page.textContent(".sheet-head"), /2 novas/);
  await page.click('[data-act="read-all"]');
  assert.match(await page.textContent(".sheet-head"), /Tudo em dia/);
  await page.click('.sheet-head [data-act="sheet-close"]');
  assert.equal(await page.locator(".sheet").count(), 0);
  assert.equal(await page.locator(".appbar .icon-btn i").count(), 0, "indicador some");
  await page.click('[data-act="notif-open"]');
  await page.locator(".notification-item").nth(2).click();
  assert.equal(await title(page), "Minhas contribuições");
  assert.equal(await page.locator(".sheet").count(), 0);
  await ctx.close();
});

test("logout volta ao login e limpa a senha", async () => {
  const { ctx, page } = await open();
  await login(page);
  await page.click('.tab[data-arg="profile"]');
  await page.click('[data-act="logout"]');
  assert.equal(await page.locator(".login").count(), 1);
  assert.equal(await page.inputValue("#password"), "");
  await ctx.close();
});

test("'Manter-me conectado' persiste a sessão; sem marcar, não", async () => {
  let { ctx, page } = await open();
  await login(page, "admin", true);
  await page.reload();
  await page.waitForSelector(".tabbar");
  assert.equal(await title(page), "Visão geral");
  await page.click('.tab[data-arg="more"]'); await page.click('[data-act="logout"]');
  await page.reload();
  assert.equal(await page.locator(".login").count(), 1);
  await ctx.close();
  ({ ctx, page } = await open());
  await login(page);
  await page.reload();
  assert.equal(await page.locator(".login").count(), 1);
  await ctx.close();
});

test("admin: abas, subpáginas e botão voltar", async () => {
  const { ctx, page } = await open();
  await login(page, "admin");
  assert.equal(await title(page), "Visão geral");
  assert.equal(await page.locator(".tab").count(), 5);
  for (const [arg, t] of [["needs", "Itens necessários"], ["agenda", "Agendamentos"], ["stock", "Estoque"], ["more", "Mais"], ["home", "Visão geral"]]) {
    await page.click(`.tab[data-arg="${arg}"]`);
    assert.equal(await title(page), t);
    assert.equal(await noHScroll(page), true, `sem rolagem horizontal em ${t}`);
  }
  await page.click('.tab[data-arg="more"]');
  await page.click('[data-arg="moves"]');
  assert.equal(await title(page), "Movimentações");
  assert.equal(await page.getAttribute('.tab[data-arg="more"]', "aria-current"), "page");
  await page.click(".appbar .back");
  assert.equal(await title(page), "Mais");
  await page.click('[data-arg="reports"]');
  assert.equal(await title(page), "Relatórios");
  await page.click('[data-act="toast"]');
  assert.match(await page.textContent(".toast"), /Relatório/);
  assert.equal(page.errors.length, 0, page.errors.join("\n"));
  await ctx.close();
});

test("admin: confirmar recebimento atualiza contagem, selo e lista", async () => {
  const { ctx, page } = await open();
  await login(page, "admin");
  assert.equal((await page.textContent('.tab[data-arg="agenda"] .badge')).trim(), "4");
  await page.click('.tab[data-arg="agenda"]');
  await page.locator('[data-act="confirm"]').first().click();
  assert.match(await page.textContent(".toast"), /Rafael Santos/);
  assert.equal((await page.textContent('.tab[data-arg="agenda"] .badge')).trim(), "3");
  assert.equal(await page.locator(".schedule-row .status.green").count(), 1);
  assert.match(await page.textContent(".card-head p"), /3 aguardando/);
  await page.click('.date-strip button:nth-child(2)');
  assert.match(await page.textContent(".empty"), /Nenhum agendamento/);
  await ctx.close();
});

test("admin: estoque — busca, filtros e movimentação (entrada, saída, validações)", async () => {
  const { ctx, page } = await open();
  await login(page, "admin");
  await page.click('.tab[data-arg="stock"]');
  assert.equal(await page.locator("#stock-results .stock-item").count(), 6);
  await page.fill("#stock-q", "OLEO");
  assert.equal(await page.locator("#stock-results .stock-item").count(), 1, "busca ignora acentos e caixa");
  await page.fill("#stock-q", "zzz");
  assert.match(await page.textContent("#stock-results"), /Nada encontrado/);
  await page.fill("#stock-q", "");
  await page.click('[data-act="stock-status"][data-arg="Crítico"]');
  assert.equal(await page.locator("#stock-results .stock-item").count(), 1);
  await page.click('[data-act="stock-status"][data-arg="Todos"]');
  await page.click('[data-act="stock-cat"][data-arg="Vestuário"]');
  assert.equal(await page.locator("#stock-results .stock-item").count(), 1);
  await page.click('[data-act="stock-cat"][data-arg="Todas"]');

  // Fralda (16 un.): crítico -> entrada de 30 => 46 (Estável)
  await page.locator(".stock-item", { hasText: "Fralda" }).locator('[data-act="move-open"]').click();
  assert.equal(await page.inputValue("#move-item"), "3");
  await page.click('[data-act="move-step"][data-arg="5"]');
  assert.equal(await page.inputValue("#move-qty"), "15");
  await page.fill("#move-qty", "30");
  assert.match(await page.textContent("#move-preview"), /16 un\. → .*46 un\./);
  await page.click('[data-act="move-save"]');
  const card = page.locator(".stock-item", { hasText: "Fralda" });
  assert.match(await card.textContent(), /46/);
  assert.match(await card.textContent(), /Estável/);

  // saída maior que o saldo é bloqueada
  await card.locator('[data-act="move-open"]').click();
  await page.click('[data-act="move-type"][data-arg="out"]');
  await page.fill("#move-qty", "999");
  await page.click('[data-act="move-save"]');
  assert.match(await page.textContent("#move-error"), /Saldo insuficiente/);
  await page.fill("#move-qty", "0");
  await page.click('[data-act="move-save"]');
  assert.match(await page.textContent("#move-error"), /maior que zero/);
  await page.fill("#move-qty", "40");
  await page.click('[data-act="move-save"]');
  assert.match(await card.textContent(), /Crítico/); // 6 un.
  await ctx.close();
});

test("admin: movimentação registrada aparece no histórico", async () => {
  const { ctx, page } = await open();
  await login(page, "admin");
  await page.click('[data-act="move-new"]');
  await page.selectOption("#move-item", "5");
  await page.click('[data-act="move-save"]');
  await page.click('.tab[data-arg="more"]'); await page.click('[data-arg="moves"]');
  assert.equal(await page.locator(".move-item").count(), 4);
  assert.match(await page.locator(".move-item").first().textContent(), /Feijão carioca.*Entrada.*\+10/);
  await ctx.close();
});

test("admin: nova necessidade valida e aparece também para o doador", async () => {
  const { ctx, page } = await open();
  await login(page, "admin");
  await page.click('.tab[data-arg="needs"]');
  await page.click('[data-act="need-open"]');
  await page.click('[data-act="need-save"]');
  assert.match(await page.textContent("#need-error"), /nome/);
  await page.fill("#need-name", "Macarrão <b>x</b>");
  await page.click('[data-act="need-save"]');
  assert.match(await page.textContent("#need-error"), /quantidade/);
  await page.fill("#need-goal", "80");
  await page.selectOption("#need-pri", "Urgente");
  await page.click('[data-act="need-save"]');
  assert.equal(await page.locator(".need").first().locator("h3").textContent(), "Macarrão <b>x</b>", "texto escapado (sem XSS)");
  assert.equal(await page.locator(".need").first().locator("h3 b").count(), 0, "nenhum HTML injetado");
  await ctx.close();
});

test("nenhuma tela transborda horizontalmente em celulares pequenos e grandes", async () => {
  for (const device of ["iPhone SE", "Pixel 5", "iPhone 14 Pro Max"]) {
    const { ctx, page } = await open(device);
    assert.equal(await noHScroll(page), true, `login em ${device}`);
    await login(page, "admin");
    for (const arg of ["home", "needs", "agenda", "stock", "more"]) {
      await page.click(`.tab[data-arg="${arg}"]`);
      assert.equal(await noHScroll(page), true, `admin ${arg} em ${device}`);
    }
    await page.click('.tab[data-arg="more"]'); await page.click('[data-act="logout"]');
    await login(page);
    for (const arg of ["needs", "schedule", "history", "profile"]) {
      await page.click(`.tab[data-arg="${arg}"]`);
      assert.equal(await noHScroll(page), true, `doador ${arg} em ${device}`);
    }
    assert.equal(page.errors.length, 0, page.errors.join("\n"));
    await ctx.close();
  }
});

test("alvos de toque têm pelo menos 40px", async () => {
  const { ctx, page } = await open("iPhone SE");
  await login(page, "admin");
  for (const arg of ["home", "agenda", "stock"]) {
    await page.click(`.tab[data-arg="${arg}"]`);
    const small = await page.evaluate(() => [...document.querySelectorAll("button:not([disabled])")].filter((b) => {
      const r = b.getBoundingClientRect(); return r.width > 0 && (r.height < 40 || r.width < 40) && !b.classList.contains("ghost");
    }).map((b) => b.textContent.trim().slice(0, 20) + " " + Math.round(b.getBoundingClientRect().width) + "x" + Math.round(b.getBoundingClientRect().height)));
    assert.deepEqual(small, [], `botões pequenos em ${arg}`);
  }
  await ctx.close();
});

test("PWA: manifest válido, ícones existem e service worker permite abrir offline", async () => {
  const { ctx, page } = await open();
  const res = await page.request.get(URL + "manifest.webmanifest");
  const m = await res.json();
  assert.equal(m.display, "standalone");
  for (const ic of m.icons) assert.equal((await page.request.get(URL + ic.src)).status(), 200, ic.src);
  await page.evaluate(() => navigator.serviceWorker.ready);
  await page.reload();
  await ctx.setOffline(true);
  await page.reload();
  assert.match(await page.textContent(".login-heading h2"), /Bem-vindo/);
  const fontOk = await page.evaluate(async () => { await document.fonts.ready; return document.fonts.check('700 16px "Manrope"'); });
  assert.equal(fontOk, true, "fontes locais carregam offline");
  await ctx.close();
});

test("modo servidor: erro de credenciais e erro de conexão são tratados", async () => {
  const { ctx, page } = await open();
  await page.route("**/config.js", (r) => r.fulfill({ contentType: "text/javascript", body: 'window.ELO_CONFIG={API_URL:"http://api.test"}' }));
  await page.route("http://api.test/token", (r) => {
    const body = r.request().postData() || "";
    return body.includes("errada") ? r.fulfill({ status: 401, body: "{}" }) : r.fulfill({ status: 200, contentType: "application/json", body: '{"access_token":"abc"}' });
  });
  await page.goto(URL);
  await page.fill("#email", "a@b.com"); await page.fill("#password", "errada");
  await page.click(".login .primary");
  await page.waitForSelector(".auth-notice");
  assert.match(await page.textContent(".auth-notice"), /Credenciais inválidas/);
  assert.equal(await page.inputValue("#email"), "a@b.com");
  await page.fill("#password", "certa");
  await page.click(".login .primary");
  await page.waitForSelector(".tabbar");
  await page.click('.tab[data-arg="profile"]'); await page.click('[data-act="logout"]');
  await page.unroute("http://api.test/token");
  await page.route("http://api.test/token", (r) => r.abort());
  await page.fill("#email", "a@b.com"); await page.fill("#password", "x");
  await page.click(".login .primary");
  await page.waitForSelector(".auth-notice");
  assert.match(await page.textContent(".auth-notice"), /Erro ao conectar/);
  await ctx.close();
});
